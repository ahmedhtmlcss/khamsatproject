using Grade_Project_.Models;
using Grade_Project_.Repository;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Grade_Project_
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            //connection string
            string Connection = builder.Configuration.GetConnectionString("cars_entity");
            builder.Services.AddDbContext<Cars_Entity>(optionBuilder =>
            {
                optionBuilder.UseSqlServer(Connection);
            });
            builder.Services.AddIdentity<Users, Roles>(
                options => options.Password.RequireDigit = true
                ).
                AddEntityFrameworkStores<Cars_Entity>();

            //Registeration
            builder.Services.AddScoped<ICar, Car_Repository>();
            builder.Services.AddScoped<IUsers,UsersRepository>();
            builder.Services.AddScoped<ICar_Brand, Car_BrandRepository>();
            builder.Services.AddScoped<ICar_Model, Car_ModelRepository>();
            builder.Services.AddScoped<ICar_Images, Car_ImagesRepositpory>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}