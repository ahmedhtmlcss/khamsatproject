﻿using Grade_Project_.DTO;
using Grade_Project_.Models;
using Microsoft.EntityFrameworkCore;

namespace Grade_Project_.Repository
{
    public class Car_Repository : ICar
    {
        Cars_Entity context;

        public Car_Repository(Cars_Entity context)
        {
            this.context = context;
        }
        public List<Car> GetAll()
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).ToList();
        }

        public Car GetById(int id)
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).FirstOrDefault(x => x.ID == id);
        }

        public void Insert(Car car)
        {
            context.Add(car);
            context.SaveChanges();
        }
        public void Delete(int id)
        {
            Car car = GetById(id);
            context.Remove(car);
            context.SaveChanges();
        }

        public void Edit(int id, Car car)
        {
            Car updated_car = GetById(id);

            updated_car.Price = car.Price;
            updated_car.Mileage = car.Mileage;
            updated_car.Made_Year = car.Made_Year;
            updated_car.Engine_Capacity = car.Engine_Capacity;
            updated_car.Transmission = car.Transmission;
            updated_car.Car_Address = car.Car_Address;
            updated_car.Description = car.Description;
            updated_car.Is_Used = car.Is_Used;
            updated_car.Is_Approved = car.Is_Approved;
            updated_car.Added_Date = car.Added_Date;
            updated_car.Car_Model_Id = car.Car_Model_Id;
            updated_car.User_Id = car.User_Id;

            context.SaveChanges();
        }

        public List<Car> GetUsedCars()
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).Where(x => x.Is_Used == true).ToList();
        }

        public List<Car> GetNewCars()
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).Where(x => x.Is_Used == false).ToList();

        }

        public List<Car> GetCarsByBrand(string brand, bool type)
        {

            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).
                Where(x => x.Is_Used == type && x.Car_Brand.Brand_Name == brand).ToList();
        }

        public List<Car> GetCarsByModel(string model, bool type)
        {
            return context.Cars.Include(e => e.Car_Model).Include(e => e.Car_Brand).Where
                (x => x.Is_Used == type && x.Car_Model.Model_Name == model).ToList();
        }

        public List<Car> GetCarsByMadeYear(int year)
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).Where(x => x.Made_Year == year).ToList();

        }

        public List<Car> GetCarsByTransmission(string type)
        {
            return context.Cars.Include(e => e.Car_Brand).Include(e => e.Car_Model).Where(x => x.Transmission == type).ToList();
        }

        public List<CarWithBrandAndModelDataDto> customizedCars(List<Car> cars)
        {
            List<CarWithBrandAndModelDataDto> customizeCars = new List<CarWithBrandAndModelDataDto>();
            for (int i = 0; i < cars.Count; i++)
            {
                CarWithBrandAndModelDataDto c1 = new CarWithBrandAndModelDataDto();
                c1.Price = cars[i].Price;
                c1.Mileage = cars[i].Mileage;
                c1.Made_Year = cars[i].Made_Year;
                c1.Engine_Capacity = cars[i].Engine_Capacity;
                c1.Transmission = cars[i].Transmission;
                c1.Car_Address = cars[i].Car_Address;
                c1.Car_Brand_Name = cars[i].Car_Brand.Brand_Name;
                c1.Car_Model_Name = cars[i].Car_Model.Model_Name;
                if (cars[i].Is_Used == true)
                {
                    c1.Status = "Used";
                }
                else
                {
                    c1.Status = "New";
                }
                customizeCars.Add(c1);
            }

            return customizeCars;
        }
    }
}
