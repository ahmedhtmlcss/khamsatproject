﻿using Grade_Project_.Models;

namespace Grade_Project_.Repository
{
    public class Car_BrandRepository : ICar_Brand
    {
        private readonly Cars_Entity _context;

        public Car_BrandRepository(Cars_Entity context)
        {
            _context = context;
        }
        public List<Car_Brand> GetAll()
        {
            return _context.Cars_Brands.ToList();
        }

        public Car_Brand GetById(int id)
        {
            return _context.Cars_Brands.FirstOrDefault(e => e.Id == id);
        }

        public void Insert(Car_Brand car_brand)
        {
            _context.Cars_Brands.Add(car_brand);
            _context.SaveChanges();
        }

        public void Edit(int id, Car_Brand car_brand)
        {
            var result = GetById(id);
            result.Brand_Name = car_brand.Brand_Name;
            result.Brand_Logo = car_brand.Brand_Logo;


            _context.SaveChanges();
        }
        public void Delete(int id)
        {
            Car_Brand result = GetById(id);
            _context.Cars_Brands.Remove(result);
            _context.SaveChanges();
        }




    }
}
