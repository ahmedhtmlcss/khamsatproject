﻿using Grade_Project_.DTO;
using Grade_Project_.Models;

namespace Grade_Project_.Repository
{
    public interface ICar
    {
        List<Car> GetAll();
        Car GetById(int id);
        void Insert(Car car);
        void Edit(int id, Car car);
        void Delete(int id);
        List<Car> GetUsedCars();
        List<Car> GetNewCars();
        List<Car> GetCarsByBrand(string brand, bool type);
        List<Car> GetCarsByModel(string model, bool type);
        List<Car> GetCarsByMadeYear(int year);
        List<Car> GetCarsByTransmission(string type);
        List<CarWithBrandAndModelDataDto> customizedCars(List<Car> cars);

    }
}
