﻿using Grade_Project_.Models;

namespace Grade_Project_.Repository
{
    public interface ICar_Brand
    {
        List<Car_Brand> GetAll();
        Car_Brand GetById(int id);
        void Insert(Car_Brand car);
        void Edit(int id, Car_Brand car);
        void Delete(int id);
    }
}
