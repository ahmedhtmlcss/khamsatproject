﻿namespace Grade_Project_.DTO
{
    public class ModelWithBrandDTO
    {
        public int Model_Id { get; set; }
        public string Model_Name { get; set; }
        public string Model_Icon { get; set; }
        public int CarBrand_Id { get; set; }
        public string? CarBrand_Name { get; set; }
    }
}
