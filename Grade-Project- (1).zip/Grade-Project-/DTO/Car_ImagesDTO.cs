﻿namespace Grade_Project_.DTO
{
    public class Car_ImagesDTO
    {
        public string Car_Image { get; set; }
        public int Car_ID { get; set; }

    }
}
