﻿using Microsoft.AspNetCore.Identity;

namespace Grade_Project_.Models
{
    public class Roles:IdentityRole<int>
    {
    }
}
